document.addEventListener('DOMContentLoaded', function () {
    // Obtém o elemento do link "Produtos"
    var produtosLink = document.getElementById('produtos');
    // Obtém o submenu
    var submenu = document.getElementById('submenu');

    // Adiciona um ouvinte de evento de clique ao link "Produtos"
    produtosLink.addEventListener('click', function (e) {
        // Previne o comportamento padrão do link
        e.preventDefault();
        // Alterna a visibilidade do submenu
        if (submenu.style.display === 'block') {
            submenu.style.display = 'none';
        } else {
            submenu.style.display = 'block';
        }
    });
});
